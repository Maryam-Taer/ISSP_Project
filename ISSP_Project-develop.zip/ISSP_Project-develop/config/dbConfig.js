module.exports = {
    host: 'localhost', // Replace with your host name
    user: 'root',      // Replace with your database username
    password: 'root',      // Replace with your database password
    database: 'issp' // // Replace with your database Name
};