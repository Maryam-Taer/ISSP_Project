var async = require("async")
const PDF = require("../models/submissionModel");
var issp = require("../config/issp_system");

exports.getAllForPDFPage = async (req, res) => {
    async.parallel(
        [
            PDF.getAllForPDFPage,
            PDF.get_year_term
        ],
        function (err, results) {
            if (err){
                res.render('error', { message: "Some error occurred while retrieving the Submissions.", role: req.user.role, 
                username: req.user.username });
            }else {
                res.render('pdfPage', { title: 'PDF Page', submissionData: JSON.stringify(results[0]), 
                year_term: JSON.stringify(results[1]), username: req.user.username, role: req.user.role });
            }
        }
    );
};

exports.get_year_term_category = async (req, res) => {
    async.parallel(
        [
            PDF.get_year_term_category,
            PDF.get_year_term
        ],
        function (err, results) {
            if (err){
                res.render('error', { message: "Some error occurred while retrieving the Submissions.", role: req.user.role, 
                username: req.user.username });
            }else {
                res.render('pdfSubmissionPage', { title: 'PDF Submission Page', submissionData: JSON.stringify(results[0]), 
                year_term: JSON.stringify(results[1]), username: req.user.username, role: req.user.role });
            }
        }
    );
};
